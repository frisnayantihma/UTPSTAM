package com.example.financialapp;

import java.text.SimpleDateFormat;
import java.util.Date;

public class ItemWalletDetail {
    public enum EnumType{
        Tagihan,
        Pemasukan,
        Gaji
    }

    private Date date;

    private EnumType type;

    private String desc;
    private String price;

    public ItemWalletDetail(Date _date, EnumType _type, String _desc, String _price){
        date = _date;
        type = _type;
        desc = _desc;
        price = _price;
    }

    public String GetDate(){
        return new SimpleDateFormat("dd/MM/yyyy").format(date);
    }

    public String GetType(){
        return type.name();
    }

    public String GetDesc(){
        return desc;
    }

    public String GetPrice(){
        String _price = "";

        if(type == EnumType.Tagihan)
            _price = "- Rp. " + price;
        else
            _price = "+ Rp. " + price;

        return _price;
    }
}
