package com.example.financialapp;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Calendar;

public class WalletFragment extends Fragment {
    private ArrayList<ItemWalletDetail> listItem;

    private GridView recyclerView;

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        recyclerView = (GridView) getView().findViewById(R.id.recycler);
        listItem = new ArrayList<>();

        DebugWalletItem();
        SetWalletAdapter();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_wallet, container, false);
    }

    private void SetWalletAdapter(){
        ItemWalletRecyclerAdapter adapter = new ItemWalletRecyclerAdapter(this.getContext(), listItem);
//        RecyclerView.LayoutManager layoutManager = new LinearLayoutManager(getActivity());

//        recyclerView.setLayoutManager(layoutManager);
//        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(adapter);
    }

    private void DebugWalletItem(){
        listItem.add(new ItemWalletDetail(Calendar.getInstance().getTime(), ItemWalletDetail.EnumType.Tagihan, "Listrik", "350.000"));
        listItem.add(new ItemWalletDetail(Calendar.getInstance().getTime(), ItemWalletDetail.EnumType.Pemasukan, "Uang Saku", "30.000"));
        listItem.add(new ItemWalletDetail(Calendar.getInstance().getTime(), ItemWalletDetail.EnumType.Gaji, "Gaji", "1.350.000"));
        listItem.add(new ItemWalletDetail(Calendar.getInstance().getTime(), ItemWalletDetail.EnumType.Gaji, "Bonus", "500.000"));
    }
}
