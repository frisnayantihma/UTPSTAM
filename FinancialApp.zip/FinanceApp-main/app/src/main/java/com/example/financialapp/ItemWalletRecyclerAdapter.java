package com.example.financialapp;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ItemWalletRecyclerAdapter extends ArrayAdapter<ItemWalletDetail> {
    private ArrayList<ItemWalletDetail> listItem;
    private RelativeLayout layoutBg;
    private ImageView imgIcon;
    private TextView textDate;
    private TextView textType;
    private TextView textDesc;
    private TextView textPrice;

    public ItemWalletRecyclerAdapter(Context context, ArrayList<ItemWalletDetail> _listItem) {
        super(context, 0, _listItem);
        listItem = _listItem;
    }

    @NonNull
    @Override
    public View getView(int position, @Nullable View convertView, @NonNull ViewGroup parent) {
        View itemView = convertView;
        if (itemView == null) {
            // Layout Inflater inflates each item to be displayed in GridView.
            itemView = LayoutInflater.from(getContext()).inflate(R.layout.item_wallet_detail, parent, false);
        }
        layoutBg = itemView.findViewById(R.id.item_wallet_bg);
        imgIcon = itemView.findViewById(R.id.item_wallet_icon);
        textDate = itemView.findViewById(R.id.item_wallet_date);
        textType = itemView.findViewById(R.id.item_wallet_type);
        textDesc = itemView.findViewById(R.id.item_wallet_desc);
        textPrice = itemView.findViewById(R.id.item_wallet_price);
        return itemView;
    }
}
